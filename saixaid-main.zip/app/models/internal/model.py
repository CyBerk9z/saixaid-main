from pydantic import BaseModel
from typing import Dict, Any

# 必要に応じて他のモデルを追加